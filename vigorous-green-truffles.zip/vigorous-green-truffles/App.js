import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, Button, Linking, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Card, Avatar } from 'react-native-paper';



const VCard = ({ owner }) => {
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [date, setDate] = useState(new Date());
  const [time, setTime] = useState(new Date());
  const [message, setMessage] = useState('');

  const handleAppointment = () => {
    alert(`Appointment requested for ${owner.name} on ${date.toDateString()} at ${time.toLocaleTimeString()}`);
  };

  const handleSendMessage = () => {
    Linking.openURL(`mailto:${owner.email}?subject=Contact&body=${message}`);
  };

  return (
    <Card style={styles.card}>
      <View style={styles.background}>
        <Image source={require('./background.jpg')} />
      </View>
      <View style={styles.header}>
        <Avatar.Image size={80} source={{ uri: owner.avatar }} style={styles.avatar} />
        <View style={styles.headerText}>
          <Text style={styles.name}>{owner.name}</Text>
          <Text style={styles.jobTitle}>{owner.jobTitle}</Text>
          <Text style={styles.company}>{owner.company}</Text>
        </View>
      </View>
      <Card.Content style={styles.content}>
        <Text style={styles.about}>{owner.about}</Text>
        <Text style={styles.detail}><Text style={styles.boldText}>Phone:</Text> {owner.phoneNumber}</Text>
        
        <Text style={styles.detail}><Text style={styles.boldText}>Email:</Text> {owner.email}</Text>
        <Text style={styles.detail}><Text style={styles.boldText}>Business Hours:</Text> {owner.businessHours}</Text>
        <Text style={styles.detail}><Text style={styles.boldText}>Services:</Text></Text>
        
        <View style={styles.services}>
          {owner.services.map((service, index) => (
            <Text key={index} style={styles.serviceItem}>• {service}</Text>
          ))}
        </View>
        
        <Text style={styles.detail}><Text style={styles.boldText}>Products:</Text></Text>
         <Image size={80} source={require('./logo.png')} style={styles.logo} />
         <Image  source={require('./grace.jpg')} style={styles.logo} />
         
      </Card.Content>
      <View style={styles.qrCodeContainer}>
        <Image source={{ uri: owner.qrCode }} style={styles.qrCode} />
      </View>
      <Card.Content style={styles.appointment}>
        <Text style={styles.appointmentLabel}>Select Appointment Date:</Text>
        <TouchableOpacity onPress={() => setShowDatePicker(true)} style={styles.datePicker}>
          <Text style={styles.datePickerText}>{date.toDateString()}</Text>
        </TouchableOpacity>
        {showDatePicker && (
          <DateTimePicker
            value={date}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              setShowDatePicker(false);
              setDate(selectedDate || date);
            }}
          />
        )}
        <Text style={styles.appointmentLabel}>Select Appointment Time:</Text>
        <TouchableOpacity onPress={() => setShowTimePicker(true)} style={styles.datePicker}>
          <Text style={styles.datePickerText}>{time.toLocaleTimeString()}</Text>
        </TouchableOpacity>
        {showTimePicker && (
          <DateTimePicker
            value={time}
            mode="time"
            display="default"
            onChange={(event, selectedTime) => {
              setShowTimePicker(false);
              setTime(selectedTime || time);
            }}
          />
        )}
        <Button title="Make an Appointment" onPress={handleAppointment} color="crimson" />
      </Card.Content>
      <Card.Content style={styles.contact}>
      </Card.Content>
      <View style={styles.socialMedia}>
        {owner.socialMedia.map((account, index) => (
          <TouchableOpacity key={index} onPress={() => Linking.openURL(account.url)} style={styles.socialMediaLink}>
            <Image source={{ uri: account.icon }} style={styles.socialMediaIcon} />
            <Text style={styles.socialMediaText}>{account.platform}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </Card>
  );
};

const sampleOwner = {
  name: 'Managbanag, Loreto Jr. C.',
  jobTitle: 'Software Engineer',
  company: 'PlasmaTech Corp',
  phoneNumber: '09974635716',
  email: 'lmanagbanag12@gmail.com',
  about: "Loreto is a software engineer with a passion for creating efficient, scalable, and innovative software solutions. With a strong foundation in computer science and hands-on experience in various programming languages and frameworks, I enjoy tackling complex problems and turning ideas into functional and user-friendly applications.",
  businessHours: 'Mon-Fri: 9am - 5pm',

  
  services: ['Web Development', 'Mobile App Development', 'Database Management'],
  products: 'https://www.facebook.com/gtcphofficial?__tn__=%3C', 
  qrCode: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/440981533_421834444131801_3666763547811734336_n.png?stp=dst-png_s206x206&_nc_cat=101&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeFeHD-VKoG1qsJu68xeGCxHjPnFKQ01DUaM-cUpDTUNRrQ7RuNjYv-HzHWz3OPBB4OKWTTOYgTlsIrk0DVLU0M2&_nc_ohc=MGMQ0DmAkB0Q7kNvgGLaItx&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QEr4bOJVCwa-187ZMNssvbhYk-e6DRTkF0U_P8O5EAGnA&oe=666B1253',
  avatar: 'https://scontent.fmnl25-3.fna.fbcdn.net/v/t39.30808-1/386546906_1795817230875271_6233913481438292808_n.jpg?stp=dst-jpg_p200x200&_nc_cat=101&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEmpxfkDTqm8P7BwtHH43z5_loUKbNCzv3-WhQps0LO_fLJ-XsyPYo6oRuxPwQpDAL_Qg-hi6Jlx4s2ofbcpu6r&_nc_ohc=8Ekr8KQ_TTQQ7kNvgHLWkgv&_nc_ht=scontent.fmnl25-3.fna&oh=00_AYA4MJk3MwUcgAei99rwEror8r-_MhGRXXaW1DqclLZVlw&oe=66494B2C',
  socialMedia: [
    { platform: 'Facebook', url: 'https://www.facebook.com/loreto.managbanag', icon: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/f1a2b5a4e002935c0ac1e6dcf8d25270' },
    { platform: 'Instagram', url: 'https://www.instagram.com/mya.mur_/', icon: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/34c9c61018544afbba6f469785acd230' },
    { platform: 'GitHub', url: 'https://github.com/LORETOMANAGBANAG-PORTFOLIO', icon: 'https://via.placeholder.com/24?text=GH' }
  ]
};

export default function App() {
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollView}>
        <VCard owner={sampleOwner} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  scrollView: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  background: {
    position: 'absolute',
  },
  card: {
    borderRadius: 15,
    borderColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 5,
    marginHorizontal: 4,
    marginVertical: 6,
    marginBottom: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 30,
    backgroundColor: '#E2EAF4',
    
  },
  avatar: {
    marginRight: 15,
  },
  headerText: {
    flex: 1,
    
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  jobTitle: {
    fontSize: 16,
    color: '#777',
  },
  company: {
    fontSize: 16,
    color: '#777',
  },
  content: {
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  about: {
    fontSize: 16,
    width: 260,
    marginBottom: 40,
    
  },
  logo: {
    width: 100,
    height: 100,
    flexDirection: 'row',
  },
  detail: {
    fontSize: 16,
    marginBottom: 5,
    color: '#555',
    flexDirection: 'row',
    alignItems: 'center',
    
  },
  boldText: {
    fontWeight: 'bold',
  },
  services: {
    marginTop: 10,
  },
  serviceItem: {
    fontSize: 16,
    color: '#555',
  },
  qrCodeContainer: {
    alignItems: 'center',
    padding: 20,
    
  },
  qrCode: {
    width: 100,
    height: 100,
  },
  appointment: {
    padding: 20,
  },
  appointmentLabel: {
    fontSize: 16,
    marginBottom: 10,
    color: '#555',
  },
  datePicker: {
    backgroundColor: '#FFE0B2',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
  },
  datePickerText: {
    fontSize: 16,
  },
  contact: {
    padding: 20,
  },
  // textInput: {
  //   borderColor: '#ccc',
  //   backgroundColor: '#FFE0B2',
  //   borderWidth: 1,
  //   borderRadius: 5,
  //   padding: 10,
  //   marginBottom: 10,
  //   fontSize: 16,
  // },
  socialMedia: {
    flexDirection: 'row',
    justifyContent: 'center',
    padding: 10,
  },
  socialMediaLink: {
    marginHorizontal: 10,
    alignItems: 'center',
  },
  socialMediaIcon: {
    width: 24,
    height: 24,
  },
  socialMediaText: {
    marginTop: 5,
    fontSize: 12,
    color: '#555',
  },
});